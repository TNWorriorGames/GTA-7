using UnityEngine;

public class OpenWorldRuntime : MonoBehaviour
{
    void Start()
    {
        BuildGround();
        BuildRoads();
        BuildBuildings();
        BuildTrees();
        CreatePlayer();
        CreateCar();
        CreateLight();
    }

    Material Mat(Color c)
    {
        var m = new Material(Shader.Find("Universal Render Pipeline/Lit"));
        if (m.shader == null) m = new Material(Shader.Find("Standard"));
        m.color = c;
        return m;
    }

    GameObject Cube(string name, Vector3 pos, Vector3 scale, Color color)
    {
        var g = GameObject.CreatePrimitive(PrimitiveType.Cube);
        g.name = name; g.transform.position = pos; g.transform.localScale = scale;
        g.GetComponent<Renderer>().material = Mat(color);
        return g;
    }

    void BuildGround()
    {
        Cube("Ground", new Vector3(0,-0.5f,0), new Vector3(300,1,300), new Color(.25f,.48f,.22f));
    }

    void BuildRoads()
    {
        for (int x=-120; x<=120; x+=40) Cube("Road", new Vector3(x,0,0), new Vector3(10,.08f,270), Color.gray);
        for (int z=-120; z<=120; z+=40) Cube("Road", new Vector3(0,0,z), new Vector3(270,.08f,10), Color.gray);
    }

    void BuildBuildings()
    {
        for (int x=-120; x<=120; x+=40)
        for (int z=-120; z<=120; z+=40)
        for (int i=0;i<2;i++)
        {
            float h = Random.Range(8f,24f);
            Vector3 p = new Vector3(x+Random.Range(-12,12), h/2, z+Random.Range(-12,12));
            Cube("Building", p, new Vector3(Random.Range(7,14),h,Random.Range(7,14)), Random.ColorHSV(.45f,.65f,.55f,.85f,.65f,.95f));
        }
    }

    void BuildTrees()
    {
        for(int i=0;i<50;i++)
        {
            float x=Random.Range(-135,135), z=Random.Range(-135,135);
            var trunk=GameObject.CreatePrimitive(PrimitiveType.Cylinder); trunk.transform.position=new Vector3(x,1,z); trunk.transform.localScale=new Vector3(.35f,1,.35f); trunk.GetComponent<Renderer>().material=Mat(new Color(.35f,.2f,.08f));
            var top=GameObject.CreatePrimitive(PrimitiveType.Sphere); top.transform.position=new Vector3(x,3,z); top.transform.localScale=Vector3.one*2.2f; top.GetComponent<Renderer>().material=Mat(new Color(.12f,.4f,.16f));
        }
    }

    void CreatePlayer()
    {
        var p = GameObject.CreatePrimitive(PrimitiveType.Capsule);
        p.name="Player"; p.transform.position=new Vector3(0,1,14);
        p.AddComponent<CharacterController>(); p.AddComponent<ThirdPersonMover>();
        var cam = new GameObject("PlayerCamera"); cam.AddComponent<FollowCamera>(); cam.GetComponent<FollowCamera>().target=p.transform;
    }

    void CreateCar()
    {
        var c = Cube("Car", new Vector3(6,.7f,16), new Vector3(3,1,5), new Color(.75f,.05f,.08f));
        c.AddComponent<SimpleCar>();
    }

    void CreateLight()
    {
        var sun = new GameObject("Sun").AddComponent<Light>(); sun.type=LightType.Directional; sun.intensity=1.3f; sun.transform.rotation=Quaternion.Euler(50,-30,0);
    }
}
