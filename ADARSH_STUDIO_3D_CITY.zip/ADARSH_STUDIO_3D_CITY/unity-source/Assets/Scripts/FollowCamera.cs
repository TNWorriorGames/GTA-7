using UnityEngine;

public class FollowCamera : MonoBehaviour
{
    public Transform target;
    Vector3 offset = new Vector3(0,4,-7);
    void LateUpdate()
    {
        if(!target) return;
        transform.position = Vector3.Lerp(transform.position, target.position + offset, 1-Mathf.Pow(.001f,Time.deltaTime));
        transform.LookAt(target.position + Vector3.up*1.4f);
    }
}
