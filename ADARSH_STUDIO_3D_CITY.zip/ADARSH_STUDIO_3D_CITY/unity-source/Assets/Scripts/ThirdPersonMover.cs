using UnityEngine;

[RequireComponent(typeof(CharacterController))]
public class ThirdPersonMover : MonoBehaviour
{
    public float speed = 6f;
    public float gravity = -18f;
    public float jump = 7f;
    CharacterController cc;
    float y;

    void Awake(){ cc=GetComponent<CharacterController>(); }

    void Update()
    {
        float x=Input.GetAxisRaw("Horizontal");
        float z=Input.GetAxisRaw("Vertical");
        Vector3 move=new Vector3(x,0,z);
        if(move.sqrMagnitude>1) move.Normalize();
        if(Input.GetKey(KeyCode.LeftShift)) move*=1.45f;

        if(cc.isGrounded){ if(Input.GetKeyDown(KeyCode.Space)) y=jump; }
        y+=gravity*Time.deltaTime;
        move.y=y;
        cc.Move(move*speed*Time.deltaTime);

        if(new Vector3(x,0,z).sqrMagnitude>.02f) transform.forward=new Vector3(x,0,z);
    }
}
