using UnityEngine;

public class SimpleCar : MonoBehaviour
{
    public float maxSpeed=18f;
    public float acceleration=24f;
    float speed;

    void Update()
    {
        float throttle=Input.GetAxis("Vertical");
        float steer=Input.GetAxis("Horizontal");
        speed=Mathf.MoveTowards(speed, throttle*maxSpeed, acceleration*Time.deltaTime);
        transform.Rotate(Vector3.up, steer*speed*2.2f*Time.deltaTime);
        transform.position += transform.forward*speed*Time.deltaTime;
        speed=Mathf.MoveTowards(speed,0,7f*Time.deltaTime);
    }
}
