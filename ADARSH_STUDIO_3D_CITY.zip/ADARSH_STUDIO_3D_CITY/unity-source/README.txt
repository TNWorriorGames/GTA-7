UNITY STARTER

This folder is starter source, not a compiled Unity WebGL build.

1. Install a current Unity 6 editor with the Web module.
2. Create/open a Unity 3D project.
3. Copy Assets/Scripts into your project's Assets/Scripts.
4. Create an empty GameObject named OpenWorldRuntime and attach OpenWorldRuntime.cs.
5. Press Play.
6. For browser publishing, switch the platform to Web and make a Release build.
7. Upload the resulting Web build files to a web host.

Input uses Unity's classic Input Manager. Set Active Input Handling to Input Manager (Old) or Both if your project uses the new system.

This starter intentionally uses only procedural primitives, so no GTA/Rockstar assets are included.
