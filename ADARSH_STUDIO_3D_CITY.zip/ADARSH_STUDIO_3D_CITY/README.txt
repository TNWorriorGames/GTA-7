ADARSH STUDIO — 3D CITY GAME

What this is:
A lightweight original 3D open-world city explorer for a GitHub Pages website.
It has third-person walking, driving, checkpoints, NPC walkers, traffic cars, mouse camera and fullscreen.
It is not GTA 5 and uses no GTA/Rockstar assets.

FASTEST WAY TO PUT IT ON YOUR WEBSITE
1. In your ADARSH-STUDIO repository, create a folder named: games
2. Upload: website-game/3d-city-game.html into games/
3. Open your existing index.html and find the Games section.
4. Paste the contents of: website-game/add-to-existing-site.html inside that section.
5. Commit changes.
6. Open your GitHub Pages site. The game should load inside the existing interface.

The game loads Three.js 0.186.0 from jsDelivr. You do not need to upload Three.js yourself.

UNITY ROUTE
The unity-source folder contains starter C# scripts for a later Unity version. A Unity Web build must be created in Unity before it can be hosted as a browser game. The browser version above is ready for GitHub Pages without a Unity build.
